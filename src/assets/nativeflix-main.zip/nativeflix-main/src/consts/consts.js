module.exports = {
    netflixColor: '#E50914',
    genres: ['action','adventure','animation','biography','comedy','crime','documentary','drama','family','fantasy','film-noir','history','horror','music','musical','mystery','romance','sci-fi','sport','thriller','war','western'],
}